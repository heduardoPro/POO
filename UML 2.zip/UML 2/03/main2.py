from cidade import Cidade
from aeroporto import Aeroporto
from tripulacao import Tripulante
from voo import Voo
from passageiro import Passageiro
from operadores import Operadores
from reserva import Reserva

lista_passageiros = []
lista_aeroportos = []
lista_voos = []
operadores = []

print('='*30, 'MENU', '='*30)
def digite():
    
    print('-'*50, "DIGITE A OPERAÇÃO DESEJADA " , '-'*50)
def executar_airport():
    digite()
    print("\n1.Criar Aeroporto \n2.Ver todos aeroportos \n3.Sair")
    opcao = int(input())

    if opcao == 1:
        cidade = Cidade(nome=input('Nome da cidade: '), estado=input('Estado da cidade: '), pais=input('País da cidade: '))
        nome = input('Nome do Aeroporto: ')
        capacidade = input('Capacidade de decolagens: ')
        aeroporto = Aeroporto(nome, capacidade, cidade)
        lista_aeroportos.append(aeroporto)
    
    if opcao == 2:
        print('AEROPORTOS')
        for i in range(len(lista_aeroportos)):
            print(lista_aeroportos[i])
        print('-'*30)

def executar_voo():
    digite()
    print("\n1.Criar Voo \n2.Ver todos os voos \n3.Ver tripulação \n4.Sair")
    opcao = int(input())

    if opcao == 1:
        destino = lista_aeroportos
        partida = lista_aeroportos
        voo = Voo(tipo=input('Informe o tipo do voo: '), codigo=input('Digite o código do voo: '), horario=input('Horário: '), partida=partida, destino=destino, assentos_livres=input('Assentos: '))
        lista_voos.append(voo)

    if opcao == 2:
        print('VOOS')
        for i in range(len(lista_voos)):
            print(lista_voos[i])

    if opcao == 3:
        pass

def executar_passageiro():
    digite()
    print("\n1.Cadastrar Passageiro \n2.Criar reserva de voo \n3.Ver listas de passageiros \n4.Sair")
    opcao = int(input())

    if opcao == 1:
        passageiro = Passageiro(nome=input('DIgite o nome completo: '), cpf=input('Informe o CPF: '), email=input('Email: '), contato=input('Telefone: '))
        lista_passageiros.append(passageiro)

    if opcao == 2:
        print('VOCE ENTROU NO SISTEMA DE RESERVAS DE VOO')
        reserva = Reserva(codigo=input(), passageiro=lista_passageiros, voo=input())
        print('Reserva feita')

    if opcao == 3:
        print('PASSAGEIROS')
        for i in range(len(lista_passageiros)):
            print('Passageiro {}.{}'.format(i, lista_passageiros[i]))

def executar_operador():
    digite()
    print('\n1.Cadastrar Operador \n2.Ver todos os Operadores cadastrados \n3.Criar reserva \n4.Sair')

    opcao = int(input())

    if opcao == 1:
        operador = Operadores()
        operadores.append(operador)

    if opcao == 2:
        print('LISTA DE OPERADORES')
        for i in range(len(operadores)):
            print(operadores[i])

    if opcao == 3:

    
while True:
    digite()
    print("\n1.Aeroporto\n2.Voo\n3.Passageiro\n4.Operador\n5.Sair\n=================================================================")
    option = int(input())
    if option == 1:
        executar_airport()
    if option == 2:
        executar_voo()
    if option == 3:
        executar_passageiro()
    if option == 4:
        executar_operador()
    if option >= 5 or  option < 1:
        break
