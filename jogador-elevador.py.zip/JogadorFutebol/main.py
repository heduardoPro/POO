from jogador import JogadorFutebol
import datetime

jogador = JogadorFutebol('Neymar', 'Atacante', datetime.date(2002, 12, 15), 'brasileiro', 1.80, 90)
print(jogador)
